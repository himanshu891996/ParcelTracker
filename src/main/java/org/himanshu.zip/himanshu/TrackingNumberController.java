package org.himanshu;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/api")
public class TrackingNumberController {

    @PostMapping("/generateTrackingNumber")
    public ResponseEntity<String> generateTrackingNumber(@RequestBody TrackingNumberRequest request) {
        // Validate the input (optional, can be extended as needed)
        if (!isValidInput(request)) {
            return ResponseEntity.badRequest().body("Invalid input parameters");
        }

        // Generate the tracking number
        String trackingNumber = generateTrackingNumber();
        return ResponseEntity.ok(trackingNumber);
    }

    // Method to validate input (e.g., ISO country code, RFC 3339 timestamp)
    private boolean isValidInput(TrackingNumberRequest request) {
        // Example validation logic for country code
        if (request.getOriginCountryId() == null || !request.getOriginCountryId().matches("^[A-Z]{2}$") || request.getDestinationCountryId() == null || !request.getDestinationCountryId().matches("^[A-Z]{2}$") || request.getCustomerName() == null || request.getCustomerName() == "" || request.getCustomerId() == null || request.getTimestamp() == null || request.getCustomerSlug() == null || request.getCustomerSlug() == "" || request.getWeight() == 0.0) {
            return false;
        }
        if (!isValidRFC3339(request.getTimestamp())){
            return false;
        }
        if (!isValidDoubleWith3Decimals(request.getWeight())){
            return false;
        }
        // Validate other parameters as needed
        return true;
    }
    private boolean isValidDoubleWith3Decimals(double value) {
        // Convert the double to a string
        String valueAsString = String.valueOf(value);

        // Regular expression to match values with at most 3 decimal places
        String regex = "^\\d*\\.?\\d{0,3}$";

        // Check if the string matches the regex
        return valueAsString.matches(regex);
    }

    private boolean isValidRFC3339(String timestamp) {
        try {
            // Try to parse the timestamp using DateTimeFormatter.ISO_OFFSET_DATE_TIME which follows RFC 3339 format
            OffsetDateTime.parse(timestamp, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
            return true; // If no exception is thrown, the timestamp is valid
        } catch (Exception e) {
            return false; // If parsing fails, it's not in RFC 3339 format
        }
    }

    // Method to generate a unique tracking number
    private String generateTrackingNumber() {
        // Generate a unique tracking number (16 chars max, regex ^[A-Z0-9]{1,16}$)
        return UUID.randomUUID().toString().replaceAll("-", "").substring(0, 16).toUpperCase();
    }
}

